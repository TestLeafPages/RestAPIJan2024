package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidents {

	


	@Test
	public void incident() {
		
	//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
	// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
		
	//Add Query parameter
		
		 RequestSpecification inputRequest = RestAssured.given()
				 .queryParam("sysparm_fields", "sys_id");
		
		//Initiate Request
		
	 Response response = inputRequest.get("incident");
	 
	 //Print request
	 response.prettyPrint();
		
	}
}
