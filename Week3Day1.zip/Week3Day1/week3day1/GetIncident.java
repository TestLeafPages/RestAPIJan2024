package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetIncident {

	
	@Test
	public void incident() {
		
	//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
	// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
		
		//Initiate Request
		
	 Response response = RestAssured.get("incident/c94b2b9e477331100b45d48f016d43a4");
	 
	 //Print request
	 response.prettyPrint();
		
	}
}
