package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident {
	
	@Test
	public void update() {
		
		//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
		
		//Form the Request
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json").when().body("{\r\n"
				+ "    \"short_description\": \"Mobile\",\r\n"
				+ "    \"description\": \"Mobile service\"\r\n"
				+ "}");
		
		//Send the Request
		Response response = inputRequest.put("incident/c94b2b9e477331100b45d48f016d43a4");
		
		//Print the response
		response.prettyPrint();
		
		//Print Status code
		int statusCode = response.getStatusCode();
		
		//print status cose
		System.out.println("Status code for the update request is -------"+statusCode);
		
		
	}

}
