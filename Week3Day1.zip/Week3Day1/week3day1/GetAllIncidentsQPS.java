package week3day1;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentsQPS {

	


	@Test
	public void incident() {
		
		Map<String,String> queryParameters=new HashMap<String,String>();
		queryParameters.put("sysparm_fields", "short_description,description,sys_id,number");
		queryParameters.put("sysparm_limit", "3");
		
	//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
	// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
		
	//Add Query parameter
		
		 RequestSpecification inputRequest = RestAssured.given()
				 .queryParams(queryParameters);
		
		//Initiate Request
		
	 Response response = inputRequest.get("incident");
	 
	 //Print request
	 response.prettyPrint();
		
	}
}
