package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncident {

	@Test
	public void delete() {
		
		//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
		
		
		Response response = RestAssured.delete("incident/c94b2b9e477331100b45d48f016d43a4");
		
		
		//status code
		int statusCode = response.getStatusCode();
		
		//print status code
		System.out.println("Status code for delete is---------"+statusCode);
		
		
	}
}
