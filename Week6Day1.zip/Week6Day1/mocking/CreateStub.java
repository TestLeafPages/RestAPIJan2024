package mocking;

import org.testng.annotations.Test;

import com.github.tomakehurst.wiremock.client.WireMock;

public class CreateStub {

	@Test
	public void create() {
	
		WireMock.stubFor(WireMock.post("/api/now/table/incident")
				.willReturn(WireMock.aResponse()
				 .withStatus(201)	
				 .withBody("{\r\n"
				 		+ "    \"result\": {\r\n"
				 		+ "        \"short_description\": \"laptop\",\r\n"
				 		+ "        \"sys_id\": \"9cfd568d471002100b45d48f016d437c\",\r\n"
				 		+ "        \"number\": \"INC0010779\",\r\n"
				 		+ "        \"description\": \"sevice my laptop\"\r\n"
				 		+ "    }")
						)
				
				);
		
		
		
		
		
		
	}
}
