package mocking;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident {
	
	@Test
	public void create() {
		
		//Add Endpoint
		
	    RestAssured.baseURI="http://localhost/api/now/table/";
		
		// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
		
		//Input request body
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json")
		.when().body("{\r\n"
				+ "    \"short_description\": \"Desktop\",\r\n"
				+ "    \"description\": \"sevice my desktop\"\r\n"
				+ "}");
		
		//Send the Request
		
	    Response response = inputRequest.post("incident");
		
		// Print response
	    
	    response.prettyPrint();
		
		
		
		
		
		
	}

}
