package oauth;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class LearnCookies {
	
	public static String cookie;
	@BeforeSuite
	public void extractCookie() {
		
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		RestAssured.authentication=RestAssured.basic("admin", "I-Ks*dzGjO63");
		Response response = RestAssured.get("incident");
		
		/*Extract Cookie*/
		 cookie = response.getCookie("JSESSIONID");
		 System.out.println(cookie);
		
		
	}
	@Test
	public void create() {
		RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json")
		        .cookie("JSESSIONID",cookie)
				.when().body("{\r\n"
				+ "    \"short_description\": \"Laptop problem\",\r\n"
				+ "    \"description\": \"Laptop not working --Charging problem\"\r\n"
				+ "}");
		Response response = inputRequest.post("incident");
		response.prettyPrint();
	}

}
