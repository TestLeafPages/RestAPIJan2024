package oauth;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClass {
	public static String token;
	@BeforeMethod
	public void createOAuth() {
		
		RestAssured.baseURI="https://dev200784.service-now.com/oauth_token.do";
		RequestSpecification inputRequest = RestAssured.given()
		.formParam("grant_type", "password")
		.formParam("client_id", "627eacadbb140210ec94a01b78e25dc2")
		.formParam("client_secret", "ixhgd4Tb#}")
		.formParam("username", "admin")
		.formParam("password", "I-Ks*dzGjO63");
		
		Response response = inputRequest.post();
		response.prettyPrint();
		token= response.jsonPath().getString("access_token");
		
		
		
		
		
		
		
		
	}

}
