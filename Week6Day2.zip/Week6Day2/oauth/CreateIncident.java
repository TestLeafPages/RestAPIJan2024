package oauth;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends BaseClass {

	@Test
	public void create() {
		
		//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		// Add Authorization
		
		RestAssured.authentication=RestAssured.oauth2(token);
		
		//Input request body
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json")
		.when().body("{\r\n"
				+ "    \"short_description\": \"Desktop\",\r\n"
				+ "    \"description\": \"sevice my desktop\"\r\n"
				+ "}");
		
		//Send the Request
		
	    Response response = inputRequest.post("incident");
		
		// Print response
	    
	    response.prettyPrint();
		
	}
}
