package chaining;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetIncident extends BaseClass {

	
    @Test(dependsOnMethods ="chaining.CreateIncident.create" )
	public void incident() {

		
		//Initiate Request
		
	 Response response = RestAssured.get("incident/"+sys_id);
	 response.then().assertThat()
	 .body("result.number", Matchers.equalTo(incNum));
	 
	 //Print request
	 response.prettyPrint();
		
	}
}
