package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncident extends BaseClass {

	@Test(dependsOnMethods = "chaining.UpdateIncident.update")
	public void delete() {
				
		
		Response response = RestAssured.delete("incident/"+sys_id);
		
		
		//status code
		int statusCode = response.getStatusCode();
		
		//print status code
		System.out.println("Status code for delete is---------"+statusCode);
		
		
	}
}
