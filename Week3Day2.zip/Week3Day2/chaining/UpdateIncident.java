package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident extends BaseClass {
	
	@Test(dependsOnMethods ="chaining.CreateIncident.create" ) //packagaename.className.MethodName
	public void update() {

		
		//Form the Request
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json").when().body("{\r\n"
				+ "    \"short_description\": \"Mobile\",\r\n"
				+ "    \"description\": \"Mobile service\"\r\n"
				+ "}");
		
		//Send the Request
		Response response = inputRequest.put("incident/"+sys_id);
		
		//Print the response
		response.prettyPrint();
		
		//Print Status code
		int statusCode = response.getStatusCode();
		
		//print status cose
		System.out.println("Status code for the update request is -------"+statusCode);
		
		
	}

}
