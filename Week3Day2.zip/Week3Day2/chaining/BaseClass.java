package chaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;

public class BaseClass {
	
	public static String sys_id;
	public static String incNum;

	@BeforeMethod
	public void setUp() {
		
	//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
	}
}
