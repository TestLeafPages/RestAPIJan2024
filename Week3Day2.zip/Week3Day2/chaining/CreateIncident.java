package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident extends BaseClass {
	
	@Test
	public void create() {
	
		
		//Input request body
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json")
		.when().body("{\r\n"
				+ "    \"short_description\": \"Desktop\",\r\n"
				+ "    \"description\": \"sevice my desktop\"\r\n"
				+ "}");
		
		//Send the Request
		
	    Response response = inputRequest.post("incident");
		
		// Print response
	    
	  //  response.prettyPrint();
	    
	    //Extract Sys_id
	     sys_id = response.jsonPath().getString("result.sys_id");
	     
	     System.out.println(sys_id);
		
	     //Extract IncidentNumber
	     
	     incNum = response.jsonPath().getString("result.number");
		
	     System.out.println(sys_id);
		
		
		
	}

}
