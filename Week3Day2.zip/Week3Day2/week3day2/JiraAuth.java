package week3day2;

import io.restassured.RestAssured;

public class JiraAuth {

	
	public void jira() {
		
		RestAssured.authentication=RestAssured.preemptive().basic("jira_username", "jira_API_Key");
	}
}
