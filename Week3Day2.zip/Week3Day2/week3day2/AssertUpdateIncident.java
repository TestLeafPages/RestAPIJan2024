package week3day2;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class AssertUpdateIncident {
	
	@Test
	public void update() {
		
		//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
		
		//Form the Request
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json").when()
				.body("{\r\n"
						+ "    \"short_description\": \"Laptop\",\r\n"
						+ "    \"description\": \"Laptop service\"\r\n"
						+ "}");
		
		//Send the Request
		Response response = inputRequest.put("incident/f605a83647f371100b45d48f016d4322");
		
		//Print the response
		//response.prettyPrint();
		
		//Assert Description
		response.then().assertThat()
		.body("result.description", 
	     Matchers.equalTo("Laptop service"));
		
		//Assert Prefix for incident number
		response.then().assertThat()
		.body("result.number",Matchers.containsString("INC"));
		
		//Status Line --HTTP/1.1 200 OK
		String statusLine = response.getStatusLine();
		System.out.println("The Status Line is --------"+statusLine);

		
		
	}

}
