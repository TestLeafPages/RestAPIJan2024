package week3day2;

import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class DynamicDataGeneration {

	
	@Test
	public void dataDynamic() {
		
		Faker fake=new Faker();
		String firstName = fake.name().firstName();
		String lastName = fake.name().lastName();
		String emailAddress = fake.internet().emailAddress();
		
		System.out.println(firstName);
		System.out.println(lastName);
		System.out.println(emailAddress);
	}
}
