package week3day2;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class AssertCreateIncident {

	
	@Test
	public void createIncident() {
		
		//Add Endpoint
		
	    RestAssured.baseURI="https://dev200784.service-now.com/api/now/table/";
		
		// Add Authorization
		
		RestAssured.authentication=RestAssured.basic("admin","I-Ks*dzGjO63");
		
		//Create Rrequest body
		
		File file=new File("./src/test/resources/createincident.json");
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json")
		.when().body(file);
		
		//Send the Request
		
		Response response = inputRequest.post("incident");
		
		//response.prettyPrint();
		
		//Assert Status code-201.
		response.then().assertThat().statusCode(Matchers.equalTo(201));
		
		//Status  Line
		String statusLine = response.getStatusLine();
		System.out.println("StatusLine -------"+statusLine);
		
		response.then().assertThat()
		.statusLine(Matchers.equalTo("HTTP/1.1 201 Created"));
		
		
		
		
		
		
	}
}
